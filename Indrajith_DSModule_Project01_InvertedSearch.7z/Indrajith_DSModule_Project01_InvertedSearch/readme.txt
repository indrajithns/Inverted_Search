Command Line Argument To Execute The Data Structure Programming Project01 For Inverted Search

Command to run all the .c files: make   
Command to run output file: ./main.exe  file1.txt   file2.txt

This will give the required output